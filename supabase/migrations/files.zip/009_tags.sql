-- ============================================================
-- RELAYS — Étiquettes (tags) colorées sur les cartes
-- ============================================================
-- Liste de tags réutilisables (prédéfinis ou créés à la volée),
-- et association many-to-many avec les tâches.

CREATE TABLE IF NOT EXISTS tags (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name       TEXT NOT NULL UNIQUE,
  color      TEXT NOT NULL DEFAULT '#6366f1',
  created_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS task_tags (
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  tag_id  UUID NOT NULL REFERENCES tags(id)  ON DELETE CASCADE,
  PRIMARY KEY (task_id, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_task_tags_task ON task_tags (task_id);

ALTER TABLE tags      ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_tags ENABLE ROW LEVEL SECURITY;

-- Quelques tags prédéfinis pour démarrer (l'utilisateur pourra en créer d'autres).
INSERT INTO tags (name, color) VALUES
  ('Urgent',        '#EF4444'),
  ('Client VIP',    '#9B59B6'),
  ('En attente',    '#F59E0B'),
  ('Interne',       '#3B82F6'),
  ('À facturer',    '#10B981'),
  ('SAV',           '#EC4899')
ON CONFLICT (name) DO NOTHING;
