-- ============================================================
-- RELAYS — Préférences de compte (page "Mon compte")
-- ============================================================
-- Préférences de notifications par email, par utilisateur.
-- Valeurs par défaut : on notifie, l'utilisateur peut se désabonner.

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS notify_email_assigned   BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_email_status     BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_email_deadlines  BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_email_weekly     BOOLEAN NOT NULL DEFAULT false;

-- notify_email_assigned  : quand une tâche m'est assignée
-- notify_email_status    : quand le statut d'une de mes tâches change
-- notify_email_deadlines : rappels d'échéance (J-1, J-3)
-- notify_email_weekly    : résumé hebdomadaire
