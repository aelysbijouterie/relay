-- ============================================================
-- RELAYS — Accès multi-département (managers sur plusieurs services)
-- ============================================================
-- Permet à une personne d'appartenir à un département principal
-- (profiles.department_id) ET à des départements supplémentaires.
-- La sidebar affiche ces départements supplémentaires comme boutons
-- cliquables pour basculer d'un service à l'autre en un clic.
--
-- Stocké comme tableau d'UUID. Vide par défaut (mono-département).

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS extra_department_ids UUID[] NOT NULL DEFAULT '{}';

-- Exemple — Audrey, manager Administratif + RH :
-- (à adapter avec les vrais identifiants ; voir la requête d'aide ci-dessous)
--
--   UPDATE profiles
--   SET extra_department_ids = ARRAY[
--     (SELECT id FROM departments WHERE slug = 'rh')
--   ]
--   WHERE email = 'audrey@aelys.fr';
--
-- Pour retrouver les slugs/ids de vos départements :
--   SELECT id, name, slug FROM departments ORDER BY name;
