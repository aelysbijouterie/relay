-- ============================================================
-- RELAYS — Modèles de cartes : champs complémentaires
-- ============================================================
-- task_templates existe déjà (001). On l'enrichit pour stocker
-- davantage de valeurs par défaut et les sous-tâches modèles.

ALTER TABLE task_templates
  ADD COLUMN IF NOT EXISTS default_deadline_days INTEGER,        -- échéance = aujourd'hui + N jours
  ADD COLUMN IF NOT EXISTS default_subtasks      JSONB DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS is_shared             BOOLEAN NOT NULL DEFAULT true;

-- default_subtasks : tableau d'objets { title, group } appliqués à la création.
