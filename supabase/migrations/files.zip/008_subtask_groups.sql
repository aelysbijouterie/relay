-- ============================================================
-- RELAYS — Listes à cocher groupées (sous-tâches organisées en listes nommées)
-- ============================================================
-- Permet d'organiser les sous-tâches d'une carte en plusieurs listes
-- nommées (ex : "Préparation", "Validation"). Les sous-tâches sans
-- groupe restent dans une liste par défaut.
--
-- position : ordre d'affichage à l'intérieur d'un groupe.

ALTER TABLE task_subtasks
  ADD COLUMN IF NOT EXISTS group_name TEXT NOT NULL DEFAULT 'Général',
  ADD COLUMN IF NOT EXISTS position   INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_subtasks_task_group
  ON task_subtasks (task_id, group_name, position);
